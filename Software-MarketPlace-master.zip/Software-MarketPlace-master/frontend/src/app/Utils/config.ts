export const config = {
    'URL': 'http://localhost:3000/graphql',
    'CLOUDINARY_URL': 'https://api.cloudinary.com/v1_1/wowdataimagestore/image/upload',
};